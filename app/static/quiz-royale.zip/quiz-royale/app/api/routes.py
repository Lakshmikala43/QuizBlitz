import sys
from datetime import datetime, timezone
from flask import current_app
from app.api import api_bp, success_response


@api_bp.route("/health")
def health_check():
    """Engine liveness probe."""
    return success_response(
        data={
            "status": "healthy",
            "service": "Quiz Royale Gameplay Engine",
            "version": "1.0.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        message="System operational",
    )


@api_bp.route("/status")
def system_status():
    """Engine runtime diagnostics and telemetry."""
    return success_response(
        data={
            "environment": current_app.config.get("ENV", "production"),
            "python_version": sys.version.split()[0],
            "database": "connected",
            "socketio_mode": current_app.config.get("SOCKETIO_ASYNC_MODE", "threading"),
            "features": {
                "multiplayer": True,
                "daily_challenge": True,
                "synthesized_audio": True,
                "zero_external_api_keys": True,
            },
        },
        message="Platform telemetry nominal",
    )


# --- Authentication & Session APIs ---
from flask import request
from flask_login import login_user, logout_user, current_user
from app.api import error_response, api_auth_required
from app.auth.services import AuthService
from app.security import rate_limit


@api_bp.route("/auth/register", methods=["POST"])
@rate_limit(requests=20, window_sec=60, bucket="api_auth_register")
def api_register():
    """Register a new player account."""
    data = request.get_json(silent=True) or request.form.to_dict()
    username = data.get("username", "")
    email = data.get("email", "")
    password = data.get("password", "")
    display_name = data.get("display_name", "")

    if not username or not email or not password:
        return error_response(
            message="Username, email, and password are required fields.",
            status_code=422,
            error_code="VALIDATION_ERROR",
        )

    success, msg, user = AuthService.register_user(
        username=username,
        email=email,
        password=password,
        display_name=display_name,
    )

    if not success or not user:
        return error_response(message=msg, status_code=400, error_code="REGISTRATION_FAILED")

    # Automatically establish session
    login_user(user)

    return success_response(
        data={
            "user": user.to_dict(),
        },
        message="Account registered successfully.",
        status_code=201,
    )


@api_bp.route("/auth/login", methods=["POST"])
@rate_limit(requests=30, window_sec=60, bucket="api_auth_login")
def api_login():
    """Authenticate player credentials and initiate session."""
    data = request.get_json(silent=True) or request.form.to_dict()
    identifier = data.get("login_identifier") or data.get("username") or data.get("email") or ""
    password = data.get("password", "")
    remember = bool(data.get("remember", False))

    if not identifier or not password:
        return error_response(
            message="Login identifier and password are required.",
            status_code=422,
            error_code="VALIDATION_ERROR",
        )

    success, msg, user = AuthService.authenticate_user(
        username_or_email=identifier,
        password=password,
    )

    if not success or not user:
        return error_response(message=msg, status_code=401, error_code="INVALID_CREDENTIALS")

    login_user(user, remember=remember)

    return success_response(
        data={
            "user": user.to_dict(),
        },
        message="Authentication successful.",
    )


@api_bp.route("/auth/logout", methods=["POST"])
@api_auth_required
def api_logout():
    """Terminate the active player session."""
    logout_user()
    return success_response(message="Logged out successfully.")


@api_bp.route("/auth/me")
@api_auth_required
def api_current_user():
    """Retrieve profile and stats of the currently authenticated player."""
    user_dict = current_user.to_dict()
    stats = current_user.statistics
    user_dict["stats"] = {
        "level": stats.level if stats else 1,
        "xp": stats.total_xp if stats else 0,
        "coins": stats.coins if stats else 0,
        "daily_streak": stats.daily_streak if stats else 0,
        "highest_streak": stats.highest_streak if stats else 0,
        "total_matches": stats.total_matches if stats else 0,
        "wins": stats.wins if stats else 0,
        "win_rate": stats.win_rate_percentage if stats else 0.0,
        "accuracy": stats.accuracy_percentage if stats else 0.0,
    }
    return success_response(data={"user": user_dict})


# --- Categories APIs ---
from app.repositories import CategoryRepository
from app.models.question import Question
from app.extensions import db
from sqlalchemy import func

category_repo = CategoryRepository()


@api_bp.route("/categories")
def api_list_categories():
    """List all active quiz categories with question totals."""
    categories = category_repo.get_active_categories()
    data = [c.to_dict() for c in categories]
    return success_response(data=data, message="Categories retrieved successfully.")


@api_bp.route("/categories/<slug>")
def api_get_category(slug: str):
    """Retrieve detailed information and difficulty breakdown for a single category."""
    cat = category_repo.get_by_slug(slug.strip().lower())
    if not cat:
        return error_response(
            message=f"Category '{slug}' not found.",
            status_code=404,
            error_code="CATEGORY_NOT_FOUND",
        )

    cat_data = cat.to_dict()

    # Difficulty breakdown
    diff_counts = (
        db.session.query(Question.difficulty, func.count(Question.id))
        .filter(Question.category_id == cat.id, Question.is_published == True)
        .group_by(Question.difficulty)
        .all()
    )
    cat_data["difficulty_breakdown"] = {diff: count for diff, count in diff_counts}

    return success_response(data=cat_data)


# --- Questions APIs ---
from app.repositories import QuestionRepository
from app.api import api_admin_required, paginate_response

question_repo = QuestionRepository()


@api_bp.route("/questions/sample")
def api_sample_questions():
    """
    Retrieve a sample batch of published questions for practice or quick-fire challenge.
    Ensures answers are scrubbed of correctness to guarantee fair play.
    """
    category_slug = request.args.get("category", "").strip().lower()
    difficulty = request.args.get("difficulty", "mixed").strip().lower()
    count = min(request.args.get("count", 5, type=int), 20)

    category_id = None
    if category_slug:
        cat = category_repo.get_by_slug(category_slug)
        if cat:
            category_id = cat.id

    questions = question_repo.get_random_questions(
        category_id=category_id,
        difficulty=difficulty if difficulty in {"easy", "medium", "hard"} else None,
        count=count,
    )

    data = [q.to_client_dict(shuffle_options=True) for q in questions]
    return success_response(data=data, message=f"Retrieved {len(data)} sample questions.")


@api_bp.route("/questions/<int:question_id>")
def api_get_question(question_id: int):
    """Retrieve an individual question by ID."""
    q = question_repo.get_by_id(question_id)
    if not q or not q.is_published:
        return error_response(message="Question not found.", status_code=404, error_code="NOT_FOUND")

    # Admins get full schema including answers and explanations; players get scrubbed schema
    if current_user.is_authenticated and getattr(current_user, "is_admin", False):
        return success_response(data=q.to_admin_dict())
    return success_response(data=q.to_client_dict(shuffle_options=False))


@api_bp.route("/questions")
@api_admin_required
def api_admin_search_questions():
    """Administrative search and pagination over the full question bank."""
    search = request.args.get("q", "")
    category_id = request.args.get("category_id", type=int)
    difficulty = request.args.get("difficulty", "")
    page = request.args.get("page", 1, type=int)

    pagination = question_repo.search_questions(
        query_text=search if search else None,
        category_id=category_id,
        difficulty=difficulty if difficulty else None,
        page=page,
        per_page=20,
    )

    items = [q.to_admin_dict() for q in pagination.get("items", [])]
    return success_response(
        data=items,
        meta={
            "page": pagination.get("page", 1),
            "pages": pagination.get("pages", 1),
            "total": pagination.get("total", 0),
        },
    )


# --- Gameplay APIs ---
from app.games.services import QuizSessionService
from app.repositories import GameRepository

game_repo = GameRepository()


@api_bp.route("/games/start", methods=["POST"])
@api_auth_required
def api_start_game():
    """Initialize a new single-player or practice game session."""
    data = request.get_json(silent=True) or request.form.to_dict()
    category_slug = data.get("category", "all")
    difficulty = data.get("difficulty", "mixed")
    question_count = int(data.get("question_count", 10))
    game_mode = data.get("game_mode", "solo")

    success, message, session = QuizSessionService.start_session(
        user_id=current_user.id,
        category_slug=category_slug,
        difficulty=difficulty,
        question_count=question_count,
        game_mode=game_mode,
    )

    if not success or not session:
        return error_response(message=message, status_code=400, error_code="SESSION_INIT_FAILED")

    return success_response(
        data=session.to_dict(),
        message="Session started successfully.",
        status_code=201,
    )


@api_bp.route("/games/<session_id>/question")
@api_auth_required
def api_get_game_question(session_id: str):
    """Retrieve the current active question for a game session."""
    success, message, payload = QuizSessionService.get_current_question_payload(
        session_id=session_id,
        user_id=current_user.id,
    )

    if not success:
        return error_response(message=message, status_code=400, error_code="QUESTION_FETCH_FAILED")

    return success_response(data=payload)


@api_bp.route("/games/<session_id>/submit", methods=["POST"])
@api_auth_required
def api_submit_answer(session_id: str):
    """Submit player's answer to the current session question."""
    data = request.get_json(silent=True) or request.form.to_dict()
    question_id = int(data.get("question_id", 0))
    selected_option_id = data.get("selected_option_id")
    if selected_option_id is not None:
        selected_option_id = int(selected_option_id)
    idempotency_key = data.get("idempotency_key")

    success, message, result = QuizSessionService.submit_answer(
        session_id=session_id,
        user_id=current_user.id,
        question_id=question_id,
        selected_option_id=selected_option_id,
        idempotency_key=idempotency_key,
    )

    if not success:
        return error_response(message=message, status_code=400, error_code="SUBMISSION_FAILED")

    return success_response(data=result, message=message)


@api_bp.route("/games/<session_id>/summary")
@api_auth_required
def api_get_game_summary(session_id: str):
    """Retrieve match performance summary and earned awards."""
    session = game_repo.get_by_id(session_id)
    if not session or session.user_id != current_user.id:
        return error_response(message="Session not found.", status_code=404, error_code="NOT_FOUND")

    summary = session.to_dict()
    summary["match_result"] = session.match_result.to_dict() if session.match_result else None
    return success_response(data=summary)


# --- Leaderboards APIs ---
from app.repositories import StatsRepository

stats_repo = StatsRepository()


@api_bp.route("/leaderboards")
def api_get_leaderboard():
    """Retrieve ranked competitive leaderboards by timeframe."""
    timeframe = request.args.get("timeframe", "all_time").strip().lower()
    if timeframe not in {"all_time", "daily", "weekly"}:
        timeframe = "all_time"

    limit = min(request.args.get("limit", 25, type=int), 100)
    offset = max(0, request.args.get("offset", 0, type=int))

    rankings = stats_repo.get_leaderboard(
        timeframe=timeframe,
        limit=limit,
        offset=offset,
    )

    podium = rankings[:3] if len(rankings) >= 3 else rankings

    return success_response(
        data={
            "timeframe": timeframe,
            "podium": podium,
            "rankings": rankings,
        },
        meta={
            "limit": limit,
            "offset": offset,
            "count": len(rankings),
        },
        message="Leaderboard retrieved successfully.",
    )


# --- Player Profiles & Achievements APIs ---
from app.repositories import UserRepository
from app.models.achievement import Achievement

user_repo = UserRepository()


@api_bp.route("/players/<username>")
def api_get_player_profile(username: str):
    """Retrieve public player card, combat stats, and unlocked trophies."""
    user = user_repo.get_by_username(username.strip())
    if not user or not user.is_active:
        return error_response(
            message=f"Player '{username}' not found.",
            status_code=404,
            error_code="PLAYER_NOT_FOUND",
        )

    stats = user.statistics
    unlocked_achievements = [pa.achievement.to_dict() for pa in user.player_achievements if pa.achievement]

    profile_data = {
        "username": user.username,
        "display_name": user.effective_display_name,
        "avatar_seed": user.avatar_seed,
        "bio": user.bio,
        "is_admin": user.is_admin,
        "member_since": user.created_at.isoformat() if user.created_at else None,
        "stats": {
            "level": stats.level if stats else 1,
            "total_xp": stats.total_xp if stats else 0,
            "coins": stats.coins if stats else 0,
            "total_matches": stats.total_matches if stats else 0,
            "wins": stats.wins if stats else 0,
            "win_rate": stats.win_rate_percentage if stats else 0.0,
            "accuracy": stats.accuracy_percentage if stats else 0.0,
            "highest_streak": stats.highest_streak if stats else 0,
            "daily_streak": stats.daily_streak if stats else 0,
            "highest_score": stats.highest_score if stats else 0,
        },
        "achievements": unlocked_achievements,
    }

    return success_response(data=profile_data)


@api_bp.route("/players/<username>/history")
def api_get_player_history(username: str):
    """Retrieve paginated match performance history for a player."""
    user = user_repo.get_by_username(username.strip())
    if not user or not user.is_active:
        return error_response(message="Player not found.", status_code=404, error_code="NOT_FOUND")

    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 10, type=int), 50)

    pagination = game_repo.get_user_match_history(user_id=user.id, page=page, per_page=per_page)
    history_items = [m.to_dict() for m in pagination.get("items", [])]

    return success_response(
        data=history_items,
        meta={
            "page": pagination.get("page", 1),
            "pages": pagination.get("pages", 1),
            "total": pagination.get("total", 0),
        },
    )


@api_bp.route("/achievements")
def api_list_achievements():
    """List all platform achievements and reward definitions."""
    achievements = Achievement.query.order_by(Achievement.tier.asc(), Achievement.id.asc()).all()
    data = [a.to_dict() for a in achievements]
    return success_response(data=data, message="Achievements retrieved successfully.")


# --- Multiplayer Arena APIs ---
from app.models.multiplayer import MultiplayerRoom
from app.multiplayer.manager import room_manager


@api_bp.route("/multiplayer/rooms")
def api_list_multiplayer_rooms():
    """List open and waiting multiplayer match lobbies."""
    rooms = (
        MultiplayerRoom.query.filter(MultiplayerRoom.status.in_(["waiting", "starting"]))
        .order_by(MultiplayerRoom.created_at.desc())
        .limit(30)
        .all()
    )
    data = [r.to_dict() for r in rooms]
    return success_response(data=data, message="Active match rooms retrieved.")


@api_bp.route("/multiplayer/rooms", methods=["POST"])
@api_auth_required
def api_create_multiplayer_room():
    """Initialize a new multiplayer room lobby."""
    data = request.get_json(silent=True) or request.form.to_dict()
    category_slug = data.get("category", "all")
    difficulty = data.get("difficulty", "medium")
    question_count = max(5, min(20, int(data.get("question_count", 10))))
    max_players = max(2, min(16, int(data.get("max_players", 8))))

    try:
        room_code = room_manager.create_room(
            host_user=current_user,
            category_slug=category_slug,
            difficulty=difficulty,
            question_count=question_count,
            max_players=max_players,
        )
        room = MultiplayerRoom.query.filter_by(room_code=room_code).first()

        return success_response(
            data=room.to_dict() if room else {"room_code": room_code},
            message="Multiplayer room created successfully.",
            status_code=201,
        )
    except Exception as e:
        return error_response(
            message=f"Failed to create multiplayer room: {str(e)}",
            status_code=400,
            error_code="ROOM_CREATION_FAILED",
        )


@api_bp.route("/multiplayer/rooms/<room_code>")
def api_get_multiplayer_room(room_code: str):
    """Retrieve match room lobby details, participants, and status."""
    clean_code = room_code.strip().upper()
    room = MultiplayerRoom.query.filter_by(room_code=clean_code).first()
    if not room:
        return error_response(
            message=f"Room '{clean_code}' not found.",
            status_code=404,
            error_code="ROOM_NOT_FOUND",
        )

    room_data = room.to_dict()
    # Fetch live participants from in-memory manager if active, else DB
    mem_participants = room_manager.get_room_leaderboard(clean_code)
    if mem_participants:
        room_data["participants"] = mem_participants
    else:
        room_data["participants"] = [p.to_dict() for p in room.participants]

    return success_response(data=room_data)


# --- Administrative APIs ---
from app.models.user import User
from app.models.category import Category
from app.models.session import MatchResult
from app.models.moderation import Report, AuditLog


@api_bp.route("/admin/overview")
@api_admin_required
def api_admin_overview():
    """Retrieve high-level operational metrics and health overview."""
    total_users = db.session.query(func.count(User.id)).scalar() or 0
    active_users = db.session.query(func.count(User.id)).filter_by(is_active=True).scalar() or 0
    total_questions = db.session.query(func.count(Question.id)).scalar() or 0
    published_questions = db.session.query(func.count(Question.id)).filter_by(is_published=True).scalar() or 0
    total_categories = db.session.query(func.count(Category.id)).scalar() or 0
    total_matches = db.session.query(func.count(MatchResult.id)).scalar() or 0
    pending_reports = db.session.query(func.count(Report.id)).filter_by(status="pending").scalar() or 0

    return success_response(
        data={
            "metrics": {
                "total_users": total_users,
                "active_users": active_users,
                "total_questions": total_questions,
                "published_questions": published_questions,
                "total_categories": total_categories,
                "total_matches": total_matches,
                "pending_reports": pending_reports,
            }
        },
        message="Admin overview metrics retrieved.",
    )


@api_bp.route("/admin/users")
@api_admin_required
def api_admin_list_users():
    """Paginated user directory search for administrator."""
    query_text = request.args.get("q", "").strip()
    status_filter = request.args.get("status", "all").strip().lower()
    page = request.args.get("page", 1, type=int)

    is_active = None
    if status_filter == "active":
        is_active = True
    elif status_filter == "suspended":
        is_active = False

    pagination = user_repo.search_users(
        query_text=query_text if query_text else None,
        is_active=is_active,
        page=page,
        per_page=20,
    )

    items = [u.to_dict() for u in pagination.get("items", [])]
    return success_response(
        data=items,
        meta={
            "page": pagination.get("page", 1),
            "pages": pagination.get("pages", 1),
            "total": pagination.get("total", 0),
        },
    )


@api_bp.route("/admin/audit-logs")
@api_admin_required
def api_admin_audit_logs():
    """Paginated immutable audit log events."""
    entity_filter = request.args.get("entity", "").strip().lower()
    page = request.args.get("page", 1, type=int)
    per_page = 25

    q = db.session.query(AuditLog)
    if entity_filter and entity_filter != "all":
        q = q.filter(AuditLog.target_entity == entity_filter)

    q = q.order_by(AuditLog.created_at.desc())
    total = q.count()
    offset = max(0, (page - 1) * per_page)
    logs = q.limit(per_page).offset(offset).all()
    pages = max(1, (total + per_page - 1) // per_page)

    items = [l.to_dict() for l in logs]
    return success_response(
        data=items,
        meta={
            "page": page,
            "pages": pages,
            "total": total,
        },
    )










